<?php
$conn = mysqli_connect("localhost","akhilyad_yadav","980637038@notes","akhilyad_akhil" ) or die ("error" . mysqli_error($conn));
?>
